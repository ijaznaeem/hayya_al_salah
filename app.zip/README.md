# rehman

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
## Keytool Command
keytool -genkey -v -keystore hayya-alal-salah.keystore -alias hayya-alal-salah -keyalg RSA -keysize 2048 -validity 10000

## signing Password
Naeem123*
## Flutter build 
flutter build appbundle  --build-number=1