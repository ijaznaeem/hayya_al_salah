package com.pakperegrine.hayya_al_salah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
