//Bottom Navigation Bar Active Icon Path
const String tabIconHome = 'assets/icons/home-icon.png';
const String tabIconCats = 'assets/icons/cat-icon.png';
const String tabIconFav = 'assets/icons/fav-icon.png';

//Bottom Navigation Bar Deactive Icon Path
const String tabIconHomeI = 'assets/icons/home-icon-i.png';
const String tabIconCatsI = 'assets/icons/cat-icon-i.png';
const String tabIconFavI = 'assets/icons/fav-icon-i.png';
